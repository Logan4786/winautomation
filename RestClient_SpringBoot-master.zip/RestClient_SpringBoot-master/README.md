# RestClient_SpringBoot
Cliente Rest Spring Boot consumindo API Json-Server

Você pode usar o repositório https://github.com/andervilo/API-Json-Server
para levantar uma API que já está pronta pra servir este projeto ou criar a sua, 
e caso já tenha uma, apenas faça as modificações no controller, model, ou repository